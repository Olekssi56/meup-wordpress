<?php if( ! defined( 'ABSPATH' ) ) exit(); ?>

<div class="el_report">
	<a href="javascript:void(0)" class="el_report_link" data-myaccount_page="<?php echo esc_attr( get_myaccount_page() ) ?>" data-id_event="<?php echo get_the_ID() ?>">
		<i class="icon_mail_alt"></i>
		<?php esc_html_e('Report', 'eventlist') ?>
	</a>
	<div class="el_wrap_form_report"></div>
	
</div>
