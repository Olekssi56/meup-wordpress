<?php if( ! defined( 'ABSPATH' ) ) exit();
?>
<button class="event_remove" data-id="<?php echo esc_attr( get_the_ID() ); ?>">
	<i class="meupicon-x" aria-hidden="true"></i>
</button>