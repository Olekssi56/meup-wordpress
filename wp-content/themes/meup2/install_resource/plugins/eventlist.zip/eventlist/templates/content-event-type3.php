<?php if( ! defined( 'ABSPATH' ) ) exit(); ?>
<?php
$post_id = get_the_ID();

$url_img = wp_get_attachment_image_url( get_post_thumbnail_id() , 'el_img_squa' );

if (has_image_size( 'el_img_squa' ) && has_post_thumbnail() && get_the_post_thumbnail()) {
	$url_img = wp_get_attachment_image_url( get_post_thumbnail_id() , 'el_img_squa' );
} else {
	$url_img = EL_PLUGIN_URI.'assets/img/no_tmb_square.png';
}

?>
<li class="event_item type3">
		<?php if ( apply_filters( 'el_ft_show_remove_btn', false ) ): ?>
			<?php do_action( 'el_loop_event_remove', $args ); ?>
		<?php endif; ?>
	<div class="image_feature" style="background-image: url(<?php echo $url_img ?>)" >
		
		
		<img src="<?php echo esc_url($url_img) ?>" alt="<?php echo get_the_title() ?>">


		<?php 
			/**
			 * Display Category
			 * Hook: el_loop_event_cat_3
			 * @hooked: el_loop_event_cat_3
			 */
			do_action( 'el_loop_event_cat_3' );
		?>
		

	</div>

	<div class="info_event">
		<div class="status-title">
			<?php 
				do_action( 'el_loop_event_title' );
				
				do_action( 'el_loop_event_status' );
			?>
		</div>
		<?php

		do_action( 'el_loop_event_ratting' );

		do_action( 'el_loop_event_time' );

		do_action( 'el_loop_event_location' );
		
		do_action( 'el_loop_event_price' );

		do_action( 'el_loop_event_favourite' );

		?>

	</div>

	
</li>



