== Description ==


== Installation ==

= Minimum Requirements =

* WordPress 5.x or greater
* PHP version 5.6 or greater
* MySQL version 5.0 or greater

= We recommend your host supports: =

* PHP version 7.0 or greater
* MySQL version 5.6 or greater
* WordPress Memory limit of 64 MB or greater (128 MB or higher is preferred)

https://www.youtube.com/watch?v=Ypn6fltn_7s

= Installation =

1. Install using the WordPress built-in Plugin installer, or Extract the zip file and drop the contents in the `wp-content/plugins/` directory of your WordPress installation.
2. Activate the plugin through the 'Plugins' menu in WordPress.


== Frequently Asked Questions ==



== Screenshots ==


== Changelog ==

= 1.0.0 - 2018-06-13 =
* Initial Public Beta Release
