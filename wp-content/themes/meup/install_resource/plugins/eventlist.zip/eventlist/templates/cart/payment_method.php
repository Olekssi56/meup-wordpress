<?php if( ! defined( 'ABSPATH' ) ) exit(); ?>
<div class="payment_method_choosed">
	<h3 class="cart_title"> <?php esc_html_e( 'Payment Method', 'eventlist' ); ?> </h3>
	<div class="content">

	</div>
</div>