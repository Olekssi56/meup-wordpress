(function ($) {
	$(document).ready(function () {

		$('#event_retrict').select2({
			maximumSelectionLength: 5
		});

		if ( ! $('#event_bound').is(":checked") ) {
				$('#event_lat').closest('tr').hide();
	        	$('#event_lng').closest('tr').hide();
	        	$('#event_radius').closest('tr').hide();
		}

        $('#event_bound').on('change',function(e){
        	if( $(this).is(":checked") ) {
	            $('#event_lat').closest('tr').show();
	            $('#event_lng').closest('tr').show();
	            $('#event_radius').closest('tr').show();
	        } else {
	        	$('#event_lat').closest('tr').hide();
	        	$('#event_lng').closest('tr').hide();
	        	$('#event_radius').closest('tr').hide();
	        }
        });

        $( ".ova_accordion" ).accordion({
        	heightStyle: "content",
			collapsible: true,
			animate: {
		        duration: 500
		    }
	    });

    });
})(jQuery);